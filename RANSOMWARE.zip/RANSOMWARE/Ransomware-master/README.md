Ransomware :


8b6bc16fd137c09a08b02bbe1bb7d670  Cerber.exe
0246bb54723bd4a49444aa4ca254845a  CryptoLocker.exe
7af48228316ffd843533181646865b30  TeslaCrypt.exe
84c82835a5d21bbcf75a61706d8ab549  WannaCry.exe
af2379cc4d607a45ac44d62135fb7015  Petya.exe
a92f13f3a1b3b39833d3cc336301b713  Petya2.exe


Password File Ransomware.zip , contact email : 0xc1r3ng@gmail.com
